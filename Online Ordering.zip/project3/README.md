To run this program:
- you need to have python and pip installed
-In your terminal go to the path where this folder was downloaded
-run the command "pip install -r requirements.txt" to download django
-run the command "python3 manage.py runserver" to access the website
