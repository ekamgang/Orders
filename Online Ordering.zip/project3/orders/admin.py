from django.contrib import admin
from .models import regular_pizza,gourmet_pizza,sandwiches,salads,pasta,drinks,toppings,order
# Register your models here.
admin.site.register(regular_pizza)
admin.site.register(gourmet_pizza)
admin.site.register(sandwiches)
admin.site.register(pasta)
admin.site.register(salads)
admin.site.register(drinks)
admin.site.register(toppings)
admin.site.register(order)
