from django.db import models

# Create your models here.
class regular_pizza(models.Model):
    name = models.CharField(max_length=64)
    priceSmall = models.DecimalField(decimal_places=2, max_digits=10)
    priceLarge = models.DecimalField(decimal_places=2, max_digits=10)

    def __str__(self):
      return f"{self.id}-{self.name}, {self.priceSmall}$,{self.priceLarge}$"

class gourmet_pizza(models.Model):
    name = models.CharField(max_length=64)
    priceSmall = models.DecimalField(decimal_places=2, max_digits=10)
    priceLarge = models.DecimalField(decimal_places=2, max_digits=10)

    def __str__(self):
      return f"{self.id}-{self.name},{self.priceSmall}$, {self.priceLarge}$"


class sandwiches(models.Model):
    name = models.CharField(max_length=64)
    priceSmall = models.DecimalField(decimal_places=2, max_digits=10)
    priceLarge = models.DecimalField(decimal_places=2, max_digits=10)

    def __str__(self):
      return f"{self.id}-{self.name},{self.priceSmall}$, {self.priceLarge}$"


class drinks(models.Model):
    name = models.CharField(max_length=64)
    priceSmall = models.DecimalField(decimal_places=2, max_digits=10)
    priceLarge = models.DecimalField(decimal_places=2, max_digits=10)

    def __str__(self):
      return f"{self.id}-{self.name}, {self.priceSmall}$, {self.priceLarge}$"


class pasta(models.Model):
    name = models.CharField(max_length=64)
    price = models.DecimalField(decimal_places=2, max_digits=10)

    def __str__(self):
      return f"{self.id}-{self.name},{self.price}$"


class salads(models.Model):
    name = models.CharField(max_length=64)
    price = models.DecimalField(decimal_places=2, max_digits=10)

    def __str__(self):
      return f"{self.id}-{self.name},{self.price}$"


class toppings(models.Model):
    name= models.CharField(max_length=64)

    def __str__(self):
        return f"{self.name}"

class order(models.Model):
    CHOICES = [
    ('Pending', "Pending"),
    ('Complete', 'Complete')
    ]
    items = models.CharField(max_length=1000)
    totalPrice=models.DecimalField(decimal_places=2, max_digits=400)
    status= models.CharField(choices=CHOICES,max_length=400,default="Pending")


    def __str__(self):
        return f"{self.items}-\n total:{self.totalPrice}-\n{self.status}"
