from django.http import HttpResponse
from django.shortcuts import render
from .models import regular_pizza,gourmet_pizza,sandwiches,salads,pasta,drinks,toppings,order
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
import smtplib
from email.mime.text import MIMEText

# Create your views here

# server = smtplib.SMTP('smtp.gmail.com', 587)
# server.login("youremailusername", "password")


def index(request):
    #if not request.user.is_authenticated:
    return render(request,"orders/index.html")



def register_view(request):
      username = str(request.POST["username"])
      Fname = str(request.POST["First_name"])
      email =str(request.POST["email"])
      password = str(request.POST["password"])
      try:
          user = User.objects.create_user(username, email, password)
      except:
            return render(request, "orders/index.html", {"message": "Username not available."})
      user.first_name=  Fname
      user.save()
      context ={
      "regular_pizza":regular_pizza.objects.all(),
      "gourmet_pizza": gourmet_pizza.objects.all(),
      "sandwiches": sandwiches.objects.all(),
      "salads": salads.objects.all(),
      "pasta": pasta.objects.all(),
      "drinks":drinks.objects.all(),
      "toppings":toppings.objects.all(),
      "name": user.first_name
      }
      return render(request,"orders/menu.html", context)


def login_view(request):
    username = str(request.POST["username"])
    password = str(request.POST["password"])
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
        context ={
          "regular_pizza":regular_pizza.objects.all(),
          "gourmet_pizza": gourmet_pizza.objects.all(),
          "sandwiches": sandwiches.objects.all(),
          "salads": salads.objects.all(),
          "pasta": pasta.objects.all(),
          "drinks":drinks.objects.all(),
          "toppings":toppings.objects.all(),
          "name": user.first_name
          }
        return render(request,"orders/menu.html", context)
    else:
        return render(request, "orders/index.html", {"message": "Invalid credentials. Try again"})

def logout_view(request):
    logout(request)
    return render(request,"orders/index.html")

def cart(request):
    cart = []
    cartPrice = []
    cart = request.POST["order"].split(",")
    cartPrice = request.POST["orderPrice"].split(",")
    cartPriceInt = []
    for i in cartPrice:
        cartPriceInt.append(float(i))
    total = sum(cartPriceInt)
    context={"cart":cart, "total":total}
    return render(request,"orders/order.html",context)

    """
    take the list from the js of the incoming page and store it in the cart list here
    take the total of the cartPrices list an store it in a Number
    pass those arguments through jinja to the order webpage for display
    cart = request.POST['cart']
    context={"cart":cart
    if request.method == 'POST':
        if 'cart' in request.POST:
            cart = request.POST['cart']
            context={"cart":cart}
            return render(request,"orders/order.html",context
    # nothing went well
    return HttpRepsonse('FAIL!!!!!')}
    """
def complete(request):
        cart = str(request.POST['order'])
        price = float(request.POST['orderPrice'])
        f = order.objects.create(items=cart, totalPrice=price , status="Pending")
        context ={"order": f}
        f.save()
        """
        msg = MIMEText("Thanks for your order please follow the link below to check the status of your order!\nhttp://127.0.0.1:8000/f.id/status\n", f)
        #server.sendmail("you@gmail.com", "target@example.com", msg)
        me='smtp.gmail.com'
        you="edwinkamgang@gmail.com"
        msg['Subject'] = 'Order confirmation'
        msg['From'] = me
        msg['To'] = you
        s = smtplib.SMTP(host='smtp.gmail.com', port=587)
        s.sendmail(me, [you], msg.as_string())
        s.quit()
        """
        return render(request,"orders/complete.html", context)

def status(request, order_id):
    orderId = order.objects.get(pk=order_id)
    status=orderId.status
    context ={"status": status}

    return render(request, "orders/status.html", context)
